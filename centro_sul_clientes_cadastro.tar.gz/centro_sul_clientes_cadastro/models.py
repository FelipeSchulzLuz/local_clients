from django.conf import settings
from django.db import models
from django.utils import timezone
from django.contrib.gis.db import models as geomodels

# Create your models here.


class Cliente(models.Model):
    nome_cliente = models.CharField(max_length=100)
    detalhes_cliente = models.TextField()
    autor = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    data_criacao = models.DateTimeField(default=timezone.now)
    
    
    def publicar(self):
        self.data_publicacao = timezone.now()
        self.save()

    def __str__(self):
        return self.titulo
