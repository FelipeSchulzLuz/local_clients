from django.apps import AppConfig


class CentroSulClientesCadastroConfig(AppConfig):
    name = 'centro_sul_clientes_cadastro'
