from django.shortcuts import render
from centro_sul_clientes_cadastro.models import Cliente
from django.utils import timezone
from django.shortcuts import redirect, get_object_or_404


# Create your views here.

def home(request):
    clientes = Cliente.objects.all().order_by("-data_criacao")
    return render(request, 'home.html', {'clientes': clientes})

