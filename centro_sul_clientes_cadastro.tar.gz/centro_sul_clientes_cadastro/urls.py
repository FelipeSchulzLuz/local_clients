from django.urls import path
from . import views

urlpatterns = [
     path('', views.home, name="home"),
     path('cliente/<int:pk>/', views.detalhe_cliente, name="detalhe_cliente"),
     path('edit_cliente/<int:pk>/', views.edit_cliente, name="edit_cliente"),
     path('cliente/new/', views.adicionar_cliente, name="adicionar_cliente"),
     

]